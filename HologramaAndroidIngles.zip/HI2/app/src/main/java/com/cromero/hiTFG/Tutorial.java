package com.cromero.hiTFG;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Tutorial extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutorial);
    }
}
